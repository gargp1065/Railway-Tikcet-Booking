Pranjal Garg
MT2021099


To run the server file server.c write the following command in terminal: 
1. gcc server.c -o server
2 ./server

To run the client file client.c write the following commands in another terminal:
1. gcc client.c -o client
2. ./client

First run the server file and then the client file.

The secret pin for admin signup is "iiitb".

Three files are needed for the database which are uploaded.
1. user
2. train
3. booking

First create an admin account and add train in the train file and then proceed.
